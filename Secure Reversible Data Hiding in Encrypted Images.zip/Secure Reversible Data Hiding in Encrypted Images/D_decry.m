function [Iori]=D_decry(III,Tn,Tp,Map)
III=double(III);
[m,n]=size(III);
key=123456;
D1_1=III;
%for i=1:m          
 %      for j=1:n
 %          if D1_1(i,j)>128||  D1_1(i,j)==128
 %              D1_1(i,j)=-(D1_1(i,j)-128);
 %          else
%               D1_1(i,j)=(D1_1(i,j));
%           end 
%       end
%end
keyw=123;

AA=reshape(D1_1,1,m*n);
x=(AA>=Tn&AA<=Tp);%�ҵ���ֵ֮�ڵ���
x=double(x);
[z,v]=find(x==1);%vΪ��ֵ֮�ڵ��������±�
AA2=AA(v);%AA2Ϊ��ֵ֮�ڵĲ�ֵ
refl=AA2;
RandStream.setGlobalStream(RandStream('mt19937ar','seed',keyw));

zrefl=refl;
[x1,y1]=size(zrefl);
RR=randperm(x1*y1);
for i=1:x1*y1
    zrefl(RR(i))=refl(i);
end
ED1=zrefl;
AA(v)=ED1;

x22=(AA<Tn|AA>Tp);%�ҵ���ֵ֮�ڵ���
x22=double(x22);
[z2,v2]=find(x22==1);%vΪ��ֵ֮�ڵ��������±�
AA22=AA(v2);%AA2Ϊ��ֵ֮�ڵĲ�ֵ
ref2=AA22;
[x2,y2]=size(ref2);
RandStream.setGlobalStream(RandStream('mt19937ar','seed',keyw));
RR=randperm(x2*y2);
zref2=ref2;
for i=1:x2*y2
   zref2(RR(i))=ref2(i);
end
ED2=zref2;
AA(v2)=ED2;
D1_2=reshape(AA,m,n);

D_Image1= D1_2;
rand('state',key);               
 random11=fix((127-(Tp+1))*rand(m,n)); 
 random12=fix((127+Tn-1)*rand(m,n)); 
for i=1:m
    for j=1:n
     if D_Image1(i,j)>Tp&&D_Image1(i,j)<=127
         E1(i,j)=mod(D_Image1(i,j)-(Tp+1)-random11(i,j),127-Tp)+(Tp+1);
     end
     if D_Image1(i,j)<Tn&&D_Image1(i,j)>=-127
          E1(i,j)=-mod(-(D_Image1(i,j)-(Tn-1))-random12(i,j),127+Tn)+(Tn-1);
     end
     if D_Image1(i,j)>=Tn&&D_Image1(i,j)<=Tp
          E1(i,j)=D_Image1(i,j);
     end
    end
end
 %E1(1,1)=161;
 E2=E1;
 [ E1] = D_func_overflow_recovery( E2,Map );
Iori=D_func_recovery_order(E1);%�õ�ԭʼͼ��

end



