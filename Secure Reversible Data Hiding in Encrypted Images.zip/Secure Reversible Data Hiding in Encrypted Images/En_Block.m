function [E_Image]=Encry(I)
[m,n]=size(I);
u=4;
v=4;
blockrow=u;
blockcol=v;
row=fix(m/u);
col=fix(n/v);
key1=9;
key2=12;
% ����
rand('seed',key1);
K=randi([0,255],row,col);
K_1=kron(K,ones(u,v));
% E_img=mod(K_1+I,256);
%[E_img]=XOR(I,K_1);
%imshow(uint8(E_img));
%imhist(uint8(E_img));
 E_img=I;

for i=1:row
    for j=1:col
        block_img{i,j}=E_img((u*i-u+1):u*i,(v*j-v+1):v*j);
    end
end
block1_img=reshape(block_img,1,row*col);
rand('seed',key2);
Index=randperm(row*col);
for i=1:row*col
    E{i}=block1_img{Index(i)};
end
E_Image=cell2mat(reshape(E,row,col));
 %   En_img=E_img;%������䣬