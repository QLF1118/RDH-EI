function [E_Image]=Test_Enimg(E1)   
[m,n]=size(E1);
for i=1:m          
       for j=1:n
           if E1(i,j)>0||  E1(i,j)==0
               E1(i,j)=E1(i,j);
           else
               E1(i,j)=abs(E1(i,j))+128;
           end 
       end
    end
 %E1(1,1)=D(1,1);
E_Image=E1;