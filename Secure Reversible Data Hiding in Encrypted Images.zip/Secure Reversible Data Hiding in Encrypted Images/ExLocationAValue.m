function [z,totalQ]=ExLocationAValue(B,n,p)
% zΪλ����Ϣ totalQΪ��ռ�ռ�

 m=0;
 totalQ=0;
 tm=1;
 for mi=p:-1:1
     m=m+B(mi+2)*(2^(tm-1));
     tm=tm+1;
 end
 if m==0
     m=2^p;
 end
 t=zeros(1,m);
 q=zeros(1,m);
 z=zeros(1,m);
q(1)=ceil(log2(n));
totalQ=totalQ+q(1);
tx=1;
for tt=q(1):-1:1
    t(1)= t(1)+B(tt+p+2)*(2^(tx-1));
    tx=tx+1;
end
 if t(1)==0
         t(1)=2^q(1);
 end
z(1)= t(1);
for loop=2:m
    q(loop)=ceil(log2(n-z(loop-1)));
    if q(loop)<1
        q(loop)=1;
    end
     totalQ= totalQ+q(loop);
     ty=1;
     for tt=q(loop):-1:1
         x=tt+p+2+(totalQ-q(loop));
        t(loop)= t(loop)+B(x)*(2^(ty-1));
        ty=ty+1;
     end
     if t(loop)==0
         t(loop)=2^q(loop);
     end
    z(loop)=t(loop)+z(loop-1);
end