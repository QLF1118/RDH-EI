function [De_Block]=De_Block(I)

[m,n]=size(I);
key1=9;
key2=12;
% ����
rand('seed',key1);
   
EI=double(I);
   
    u=4;
    v=4;
blockrow=u;
blockcol=v;
row=fix(m/u);
col=fix(n/v);
for i=1:row
    for j=1:col
        block_img{i,j}=EI((u*i-u+1):u*i,(v*j-v+1):v*j);
    end
end
block1_img=reshape(block_img,1,row*col);
rand('seed',key2);
Index=randperm(row*col);
k=1;
for i=1:row*col
   
scrI(Index(k))=block1_img(i);
k=k+1;
end
scrambling2=reshape(scrI,row,col);
De_Block=cell2mat(scrambling2);%�����һָ���ͼ��