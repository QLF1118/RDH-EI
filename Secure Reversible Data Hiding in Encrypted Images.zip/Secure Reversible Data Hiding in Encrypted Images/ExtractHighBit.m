function block=ExtractHighBit(HighBit,s)

n=s*s;
%% ����na
xx=ceil(0.16*n);
na=1;
for i=1:xx
    bitLength=ceil(log2(i));
    if bitLength<1
        bitLength=1;
    end
    LocationLength=i*ceil(log2(n));
    nna(i)=n-2-bitLength-LocationLength;
    if i>1&&nna(i)>=0&&nna(i)<nna(i-1)
        na=i;
    end
end
%% ��������������m�Ŀռ�p
p=ceil(log2(na));
if p<1
    p=1;
end

%% ���ݱ����Ϣ�ָ���λ
High_data=HighBit;
number=1;
while ~isempty(High_data)
    point=1;temp=1;
    %   ȫ1
    if High_data(point)==0  
        block{number}=ones(s,s);
        number=number+1;
        temp=temp+1;
    end

    % �󲿷�Ϊ1
    if High_data(point)==1&&High_data(point+1)==0
        [z,totalQ]=ExLocationAValue(High_data,n,p);% ��ȡ�������ص�λ����Ϣ
        zx=size(z,2);
        block{number}=ones(s,s);
        for kzx=1:zx
            block{number}(z(kzx))=0;
        end
        block{number}=block{number}';
        number=number+1;
        temp=temp+2+totalQ+p;
    end
    
    % bad
    if High_data(point)==1&&High_data(point+1)==1
        next=point+2;
        block{number}=zeros(s,s);
        block{number}(1:s*s)=High_data(next:next+s*s-1);
        number=number+1;
        temp=temp+2+s*s;
    end
    size_H=size(High_data,1);
%     point=temp+1;
    High_data=High_data(temp:size_H);
end
    
    