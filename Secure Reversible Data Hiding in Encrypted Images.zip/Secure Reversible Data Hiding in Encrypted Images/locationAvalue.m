function [loacationLength,Bt]=locationAvalue(Ln,n)
sn=size(Ln,1);
q=zeros(1,sn);%ÿһ��λ�ó���
t=zeros(1,sn);%��ŵ�ֵ
q(1)=ceil(log2(n));
t(1)=Ln(1);
for i=2:sn
    xx=ceil(log2(n-Ln(i-1)));
    if xx<1
        q(i)=1;
    else q(i)=xx;
    end
    t(i)=Ln(i)-Ln(i-1);
end
loacationLength=0;
for mm=1:sn
      loacationLength=loacationLength+q(mm);
end
Bt=ones(1,loacationLength);
k=1;

for i=1:sn
    for j=q(i):-1:1
        Bt(k)=bitget(t(i),j);
        k=k+1;
    end
end
