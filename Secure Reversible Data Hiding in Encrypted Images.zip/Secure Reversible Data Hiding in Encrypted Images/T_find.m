function [Tn,Tp]=T_find(I)
t=tabulate(I(:));
A=t(:,2);
x=find(A>=1000);
[c,v]=size(x);
B=t(:,1);
Tn=B(x(1));
Tp=B(x(c));
end